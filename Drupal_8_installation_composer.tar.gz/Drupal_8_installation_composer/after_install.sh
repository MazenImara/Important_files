#!/bin/bash
#
# Author: Roland Myrvold
# Version: 0.0.1
# LICENSE: GPL+2
